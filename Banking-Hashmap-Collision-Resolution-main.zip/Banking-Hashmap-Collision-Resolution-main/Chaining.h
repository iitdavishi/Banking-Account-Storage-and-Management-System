#ifndef CHAINING_H
#define CHAINING_H

#include "BaseClass.h"
#include <iostream>

class Chaining : public BaseClass {
public:
    void createAccount(std::string id, int count) override;
    std::vector<int> getTopK(int k) override;
    int getBalance(std::string id) override;
    void addTransaction(std::string id, int count) override;
    bool doesExist(std::string id) override;
    bool deleteAccount(std::string id) override;
    int databaseSize() override;
    int hash(std::string id) override;
    Chaining();
    ~Chaining();
    
private:
    int num_of_account;
    int prime;
    
    // Other data members and functions specific to Chaining
};

#endif // CHAINING_H
